const sessionSecret = "your-session-secret-key";
const emailUser = "chadrick.shanahan83@ethereal.email";
const emailPassword = "fThF4yJB6AGdrzCuVq";

module.exports = {
  sessionSecret,
  emailUser,
  emailPassword
};